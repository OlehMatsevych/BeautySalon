
/* ДАНІ ПРО ПРАЦІВНИКІВ */
let data = [
    {
        "name":"Оксана",
        "sur":"Бойко",
        "age":"21"
    },
    {
        "name":"Ольга",
        "sur":"Стужук",
        "age":"19"
    },
    {
        "name":"Іванна",
        "sur":"Кулик",
        "age":"25"
    }

]
export default data;